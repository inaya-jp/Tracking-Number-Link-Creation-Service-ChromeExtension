// background.js
chrome.contextMenus.create({
    id: "createTrackingLink",
    title: "追跡番号のリンクを作成",
    contexts: ["selection"]
  });
  
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "createTrackingLink") {
      const selectedText = info.selectionText;
      if (selectedText) {
        const url = `https://www.trackings.ta-yan.ai/?trackingNumber=${encodeURIComponent(selectedText)}`;
        chrome.tabs.create({ url: url });
      }
    }
  });
  
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "getSelectedText") {
      const selectedText = message.data;
      sendResponse({ selectedText });
    }
  });
  