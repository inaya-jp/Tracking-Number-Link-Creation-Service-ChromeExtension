// popup.js
document.getElementById('trackButton').addEventListener('click', () => {
  const trackingNumber = document.getElementById('trackingNumber').value.trim();
  if (trackingNumber !== '') {
    const url = `https://www.trackings.ta-yan.ai/?trackingNumber=${encodeURIComponent(trackingNumber)}`;
    chrome.tabs.create({ url: url });
    document.getElementById('status').textContent = 'リンクを作成しました。';
  } else {
    document.getElementById('status').textContent = '追跡番号を入力してください。';
  }
});
